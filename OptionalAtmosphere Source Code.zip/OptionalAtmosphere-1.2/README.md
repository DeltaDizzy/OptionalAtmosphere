README

1. Download the mods Kopernicus (http://forum.kerbalspaceprogram.com/index.php?/topic/140580-130-122-kopernicus-release-4-june-15/) (1.3.0 2 IMPORTANT !!) and the mods ModuleManager (http://forum.kerbalspaceprogram.com/index.php?/topic/50533-130-module-manager-281-june-29th-2017-with-n-cats-physics/) (2.8.0 IMPORTANT !!)

2. Put the mod files in the GameData folder

3. Start the game (KSP)

4. Have fun :)

And if you have a suggestion or find bugs or errors, contact us (pikmin-123@hotmail.com or make a private message in the forum of KSP) Thank you very much!
